package com.skull1.hackathon1.Selections;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.skull1.hackathon1.Adapter.MyAdapter;
import com.skull1.hackathon1.Front.MainActivity;
import com.skull1.hackathon1.R;

import java.util.ArrayList;
import java.util.List;

public class InfantActivity extends AppCompatActivity {
    RecyclerView mRecyclerView;
    List<InfantDetails> myInfantList;
    InfantDetails mInfantDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_infant);

        mRecyclerView = (RecyclerView)findViewById(R.id.recyclerView);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(InfantActivity.this,1);
        mRecyclerView.setLayoutManager(gridLayoutManager);

        myInfantList = new ArrayList<>();

        mInfantDetails = new InfantDetails("BCG","At birth or as early as possible till one year of age","0.1ml",R.drawable.infant1);
        myInfantList.add(mInfantDetails);

        mInfantDetails = new InfantDetails("Hepatitis B - Birth dose","At birth or as early as possible within 24 hours","0.5 ml",R.drawable.infant2);
        myInfantList.add(mInfantDetails);
        mInfantDetails = new InfantDetails("OPV-0","At birth or as early as possible within the first 15 days","2 drops",R.drawable.infant3);
        myInfantList.add(mInfantDetails);
        mInfantDetails = new InfantDetails("IPV","Two fractional dose at 6 and 14 weeks of age","0.1 ml",R.drawable.infant4);


        myInfantList.add(mInfantDetails);

        MyAdapter myAdapter = new MyAdapter(InfantActivity.this,myInfantList);
        mRecyclerView.setAdapter(myAdapter);

    }
}
