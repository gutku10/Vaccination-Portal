package com.skull1.hackathon1.Selections;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.skull1.hackathon1.R;

public class PregActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preg);
    }
}
