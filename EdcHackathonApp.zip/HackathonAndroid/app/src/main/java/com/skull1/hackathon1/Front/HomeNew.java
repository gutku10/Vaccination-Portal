package com.skull1.hackathon1.Front;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.core.view.GravityCompat;
import androidx.appcompat.app.ActionBarDrawerToggle;

import android.view.MenuItem;

import com.google.android.material.navigation.NavigationView;
import com.skull1.hackathon1.Login.CustomerLoginActivity;
import com.skull1.hackathon1.Login.loginpage;
import com.skull1.hackathon1.Login.signparent;
import com.skull1.hackathon1.R;
import com.tomer.fadingtextview.FadingTextView;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.view.View;
import android.widget.Button;

import java.util.concurrent.TimeUnit;

public class HomeNew extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private FadingTextView fadingTextView;
    private Button button;



    DrawerLayout drawer;
    NavigationView navigationView;
    Toolbar toolbar=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_new);
        Toolbar toolbar = findViewById(R.id.toolbar);
        fadingTextView = findViewById(R.id.fading_text_view);
        setSupportActionBar(toolbar);
        button = findViewById(R.id.official);
        getSupportActionBar().setTitle("Home");


        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView= (NavigationView)findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent browserIntent=new Intent(Intent.ACTION_VIEW, Uri.parse("http://nhp.gov.in/universal-immunisation-programme_pg"));
                startActivity(browserIntent);

            }
        });
    }



    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home_new, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }



    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        switch (id) {

            case R.id.register: {

                Intent h= new Intent(HomeNew.this, loginpage.class);
                startActivity(h);

                //do somthing
                break;
            }
            case R.id.maps: {

                Intent h= new Intent(HomeNew.this,PermissionsActivity.class);
                startActivity(h);

                //do somthing
                break;
            }
            case R.id.det: {

                Intent h= new Intent(HomeNew.this,SelectActivity.class);
                startActivity(h);

                //do somthing
                break;
            }
            case R.id.schedule: {

                Intent h= new Intent( HomeNew.this,CustomerLoginActivity.class);
                startActivity(h);

                //do somthing
                break;
            }
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
